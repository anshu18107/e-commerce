
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>TribalMarket</title>
    <link rel="shortcut icon" href="./img/srtcticon.png" type="image/png" >

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <link  href="style1.css" rel="stylesheet" type="text/css"/>
  </head>

  <body>
      <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
      <div class="header">
        <div class="inner-header">
            <div class="logo"><b><span class="glyphicon glyphicon-fire" aria-hidden="true"></span>TribalMarket</b></div>
             
      
               <div class="header-link"><a href="http://localhost/Emarket/login.php">Logout</a> </div>
               
                <div class="header-link"><a href="http://localhost/Emarketproductspage/index.php" >Dashboard</a> </div>
        </div>
    </div>
      
    
<div class="container">

      <div class="page-header">
        <h1><c href="index.php">Organic Health</c></h1>
        
      </div>
      

    
  
<div class="col-md-4"> </br>
<img src="img/61JpfOkbEFL._SY500_.jpg" width="300" alt="..." class="img-rounded">
<h4>HERBAL COFFEE </h4>
<h5> Price:11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>

<div class="col-md-4"> </br>
<img src="img/71oIoWxfY7L._SX500_.jpg" width="300" alt="..." class="img-rounded">
<h4> DESI GHEE </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>


<div class="col-md-4"> </br>
<img src="img/0022610_orna-organic-black-pepper-whole-vacuum (1).jpg" width="300" alt="..." class="img-rounded">
<h4> ORGANIC PEPPER  </h4>
<h5> Price:12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
      
    <div class="col-md-4"> </br> 
<img src="img/44278878_thumbnail_med_3e8af68d-87b7-4864-8c30-7ef35655db6f.jpg" width="300" alt="..." class="img-rounded">
<h4>TRIBAL CHAI   </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
       
        
       
       
        <div class="col-md-4"> </br> 
<img src="img/A807C289-F68E-4EA5-89D2-DB75C2440A85.jpg" width="300" alt="..." class="img-rounded">
<h4>IMLI </h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
 <div class="col-md-4"> </br> 
<img src="img/garam_masala_side_logo_2000x.jpg" width="300" alt="..." class="img-rounded">
<h4>GARAM MASALA </h4>
<h5> Price: 15</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
    <div class="col-md-4"> </br> 
<img src="img/images (1).jpg" width="300" alt="..." class="img-rounded">
<h4>RAW HONEY</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
        
 
        

        
        
       
        
        

        
        
    
        <div class="col-md-4"> </br> 
<img src="img/images (2).jpg" width="300" alt="..." class="img-rounded">
<h4>CHAT MASALA</h4>
<h5> Price: 12</h5>

<a href="https://imjo.in/5fHGQn" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
    <div class="col-md-4"> </br> 
<img src="img/images (3).jpg" width="300" alt="..." class="img-rounded">
<h4>RED CHILLI POWDER</h4>
<h5> Price: 11</h5>

<a href="https://imjo.in/pjmz3H" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    <div class="col-md-4"> </br> 
<img src="img/images (4).jpg" width="300" alt="..." class="img-rounded">
<h4>NEEM LEAVES</h4>
<h5> Price: 12</h5>

<a href="https://imjo.in/5fHGQn" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    <div class="col-md-4"> </br> 
<img src="img/images.jpg" width="300" alt="..." class="img-rounded">
<h4>TURMERIC POWDER</h4>
<h5> Price: 11</h5>

<a href="https://imjo.in/pjmz3H" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    <div class="col-md-4"> </br> 
<img src="img/moong-dal-split-without-chilka-frent-img-mPjkz38.jpg" width="300" alt="..." class="img-rounded">
<h4>MOONG DAL</h4>
<h5> Price: 12</h5>

<a href="https://imjo.in/5fHGQn" target="_blank" class="btn btn-success"> Buy Now </a>
</div>

  <div class="col-md-4"> </br> 
<img src="img/images (1).jpg" width="300" alt="..." class="img-rounded">
<h4>RAW HONEY</h4>
<h5> Price: 14</h5>

<a href="https://imjo.in/9p2Nsb" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
   
    
     <div class="col-md-4"> </br> 
<img src="img/product14_herbal_tulsiginger.02.jpg" width="300" alt="..." class="img-rounded">
<h4>HERBAL TEA</h4>
<h5> Price: 14</h5>

<a href="https://imjo.in/9p2Nsb" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
     <div class="col-md-4"> </br> 
<img src="img/Salt_3.jpg" width="300" alt="..." class="img-rounded">
<h4>BLACK SALT</h4>
<h5> Price: 14</h5>

<a href="https://imjo.in/9p2Nsb" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    

   <div class="col-md-4"> </br> 
<img src="img/organic-orthodox-black-tea-500x500.jpg" width="300" alt="..." class="img-rounded">
<h4>BLACK TEA</h4>
<h5> Price: 11</h5>  
    
     
    
</div> <!-- /container --></br></br>


  </body>
</html>
