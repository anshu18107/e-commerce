<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <title>User registration form</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            .top_margin{
                margin-top:20px;
            }
        </style>
        
        <!---- The page has a title weather entered page-->

<title>Aboutus</title>
<link rel="shortcut icon" href="./img/srtcticon.png" type="image/png" >

<!---- External css file index.css placed in the folder css is linked-->

<link  href="style.css" rel="stylesheet" type="text/css"/>

    </head>
</head>
<body>
    
    <div class="header">
        <div class="inner-header">
            <div class="logo"><a><span class="glyphicon glyphicon-fire" aria-hidden="true"></span>Tribal Market</a></div>
        
            <div class="header-link"><a href="http://localhost/Emarket/dashboard.php">Back</a> </div>
        </div>
    </div>
    
    <div class="content">
       <div class="banner-image">
           <div class="inner-banner-image">
              <center>
               <div class="banner_content">
                   
                   

<h1>About Us</h1>
<h4>Hi! we are b-tech students trying to offer services to people by starting this website called
    "WEATHER REPORT".This website was designed to provide weather updates to people.It has a searching
    platform that ensures you to check weather all around the globe.Weather is an important aspect of 
    life as it impacts our every day goings by its beautiful layers of aura that surrounds us.We have made 
    an effort to reach out to the people through this website.Hope you guys like it.</h4>     
                                     
                      
                   
               </div>
                            </center>
                   
                    
                </div>
              
           </div>
        </div>

            

</body>
</html>


