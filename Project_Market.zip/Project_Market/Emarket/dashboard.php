<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">


<title>TribalMarket</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            .top_margin{
                margin-top:20px;
            }
        </style>
        <!---- The page has a title Lifestyle Store-->

<title>TribalMarket</title>
<link rel="shortcut icon" href="./img/srtcticon.png" type="image/png" >

<!---- External css file index.css placed in the folder css is linked-->

<link  href="style.css" rel="stylesheet" type="text/css"/>



</head>
<body>
    
    <div class="header">
        <div class="inner-header">
            <div class="logo"><a><span class="glyphicon glyphicon-fire" aria-hidden="true"></span>TribalMarket</a></div>
            
           
            <div style="color:green;" class="header-link"  ><z><span class="glyphicon glyphicon-stop" aria-hidden="true"></span> Online</z> </div>
        </div>
    </div>

  
    
    
    
    
    <nav class="navbar navbar-dark bg-dark">
  <a class="navbar-brand" href="#">
    <img src="img/tripp-2.jpg"  width="50" height="50" class="d-inline-block align-top" alt="">
<div class="dropdown">
  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
    Dropdown button
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="#">Link 1</a>
    <a class="dropdown-item" href="#">Link 2</a>
    <a class="dropdown-item" href="#">Link 3</a>
  </div>
</div>
  </a>
</nav>



<!--main content-->

    
       <div class="banner-image">
           <div class="inner-banner-image">
              <center>
               <div class="banner_content">
                   <form class="form-inline">
  
  <div class="form-group mx-sm-10 mb-10">
    <label for="inputPassword2" class="sr-only">Password</label>
    <input type="password" class="form-control" id="inputPassword2" placeholder="Password">
  </div>
  <button type="submit" class="btn btn-primary mb-2">Confirm identity</button>
</form>
                </div>
              </center>
           </div>
        </div>

        
<!--thumbnail-->

    <div class="container">

<!--cameras-->

        <div class="items">
            <a href="#" >
                <img src="img/camera.jpg" alt="cameras" class="thumbnail">
                    <div class="caption">         <h2>Cameras</h2>
                        <p>Choose among the best available in the world.</p>
                    </div>
            </a>
        </div>

<!--watches-->

        <div class="items">
            <a href="#" >
                <img src="img/watch.jpg" alt="watches" class="thumbnail">
                    <div class="caption">         <h2>Watches</h2>
                        <p>Original watches from the best brands.</p>
                    </div>
            </a>
        </div>

<!--shirts-->

        <div class="items">
            <a href="lifestyle.com/shirts">
                <img src="img/shirt.jpg" alt="shirts" class="thumbnail">
                    <div class="caption">         <h2>Shirts</h2>
                        <p>Our exquisite collection of shirts.</p>
                    </div>
            </a>
        </div>

    </div>


<!--thumbnail-->

    <div class="container">

<!--cameras-->

        <div class="items">
            <a href="#" >
                <img src="img/camera.jpg" alt="cameras" class="thumbnail">
                    <div class="caption">         <h2>Cameras</h2>
                        <p>Choose among the best available in the world.</p>
                    </div>
            </a>
        </div>

<!--watches-->

        <div class="items">
            <a href="#" >
                <img src="img/watch.jpg" alt="watches" class="thumbnail">
                    <div class="caption">         <h2>Watches</h2>
                        <p>Original watches from the best brands.</p>
                    </div>
            </a>
        </div>

<!--shirts-->

        <div class="items">
            <a href="lifestyle.com/shirts">
                <img src="img/shirt.jpg" alt="shirts" class="thumbnail">
                    <div class="caption">         <h2>Shirts</h2>
                        <p>Our exquisite collection of shirts.</p>
                    </div>
            </a>
        </div>

    </div>


<!--footer-->

        <footer class="footer">
            Copyright&copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000
        </footer>









            </div>
    

    
</body>
</html>