
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>TribalMarket</title>
    <link rel="shortcut icon" href="./img/srtcticon.png" type="image/png" >

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <link  href="style1.css" rel="stylesheet" type="text/css"/>
  </head>

  <body>
      <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
      <div class="header">
        <div class="inner-header">
            <div class="logo"><b><span class="glyphicon glyphicon-fire" aria-hidden="true"></span>TribalMarket</b></div>
             
      
               <div class="header-link"><a href="http://localhost/Emarket/login.php">Logout</a> </div>
               
                <div class="header-link"><a href="http://localhost/Emarketproductspage/index.php" >Dashboard</a> </div>
        </div>
    </div>
      
    
<div class="container">

      <div class="page-header">
        <h1><c href="index.php">Jewellery</c></h1>
        
      </div>
      

    
  
<div class="col-md-4"> </br>
<img src="img/71mjFCuBSDL._UL1500_.jpg" width="300" alt="..." class="img-rounded">
<h4> LUCKY CHARM </h4>
<h5> Price:11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>

<div class="col-md-4"> </br>
<img src="img/817oeABAOwL._UL500_.jpg" width="300" alt="..." class="img-rounded">
<h4> RAINBOW NECKLACE </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>


<div class="col-md-4"> </br>
<img src="img/1562708033113_0..jpg" width="300" alt="..." class="img-rounded">
<h4> PENDANT </h4>
<h5> Price:12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
      
    <div class="col-md-4"> </br> 
<img src="img/download (1).jpg" width="300" alt="..." class="img-rounded">
<h4>METAL NECK RING  </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
       
        
       
       
        <div class="col-md-4"> </br> 
<img src="img/download (3).jpg" width="300" alt="..." class="img-rounded">
<h4>SILVER NECKLACE</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
 <div class="col-md-4"> </br> 
<img src="img/download (4).jpg" width="300" alt="..." class="img-rounded">
<h4>STONE NECKLACE</h4>
<h5> Price: 15</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
    <div class="col-md-4"> </br> 
<img src="img/download.jpg" width="300" alt="..." class="img-rounded">
<h4>METAL NECKLACE</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
        
 
        
        <div class="col-md-4"> </br> 
<img src="img/HTB152SVnuuSBuNjy1Xcq6AYjFXah.jpg" width="300" alt="..." class="img-rounded">
<h4>BEAD NECKLACE</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
       
        
        

        
        <div class="col-md-4"> </br> 
<img src="img/images (1).jpg" width="300" alt="..." class="img-rounded">
<h4>SILVER EARRINGS</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/images (2).jpg" width="300" alt="..." class="img-rounded">
<h4>BOLD MOON LOCKET</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
      <div class="col-md-4"> </br> 
<img src="img/images (3).jpg" width="300" alt="..." class="img-rounded">
<h4>TRADITIONAL EARRING</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/images.jpg" width="300" alt="..." class="img-rounded">
<h4>MODERN TRIBAL NECKLACE</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    <div class="col-md-4"> </br> 
<img src="img/product-500x500.jpg" width="300" alt="..." class="img-rounded">
<h4>LEAF NECKLACE</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
   <div class="col-md-4"> </br> 
<img src="img/Statement-blue-turquoise-tribal-beaded-necklace-set-42086_1_full.jpg" width="300" alt="..." class="img-rounded">
<h4>BLUE GEMSTONE</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>      
    
     <div class="col-md-4"> </br> 
<img src="img/download (2).jpg" width="300" alt="..." class="img-rounded">
<h4>SILVER LEAF NECKLACE</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
</div> <!-- /container --></br></br>

<footer class="footer">
            Copyright&copy; TribalMarket. All Rights Reserved | Contact Us: +91 99900 00000
        </footer>
  </body>
</html>
