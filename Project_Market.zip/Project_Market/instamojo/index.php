
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>TribalMarket</title>
    <link rel="shortcut icon" href="./img/srtcticon.png" type="image/png" >

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <link  href="style1.css" rel="stylesheet" type="text/css"/>
  </head>

  <body>
      <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
      <div class="header">
        <div class="inner-header">
            <div class="logo"><b><span class="glyphicon glyphicon-fire" aria-hidden="true"></span>TribalMarket</b></div>
             
      
               <div class="header-link"><a href="http://localhost/Emarket/login.php">Logout</a> </div>
               
                <div class="header-link"><a href="http://localhost/Emarketproductspage/index.php" >Dashboard</a> </div>
        </div>
    </div>
      
    <div class="container">

      <div class="page-header">
        <h1><c href="index.php">Clothing</c></h1>
        <p class="lead">FEMALE</p>
      </div>

    
  
<div class="col-md-4"> </br>
<img src="img/616to2vSAIL._UX500_.jpg" width="300" alt="..." class="img-rounded">
<h4> COTTON CHANDERI SUIT </h4>
<h5> Price:11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>

<div class="col-md-4"> </br>
<img src="img/African-Dresses-for-Women-Dashiki-African-Print-Dress-Tribal-Ethnic-Fashion-Ladies-Clothes-Casual-Sexy-Beach (1).jpg" width="300" alt="..." class="img-rounded">
<h4> TANKA EMBROIDERY KURTI  </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>


<div class="col-md-4"> </br>
<img src="img/tribal-print-midi-dress-brown-25531-4.jpg" width="300" alt="..." class="img-rounded">
<h4> PATTERN ART DRESS  </h4>
<h5> Price:12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
      
    <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215049_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>GREEN TUSSAR TRIBAL STOLE  </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
       
        
       
       
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215205_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>CHIFFON HAND DUPATTA  </h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
 <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215131_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>SILK SKIRT SET </h4>
<h5> Price: 15</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
    <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215228_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>BLOCK PRINT DUPATTA</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
        
 
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_222847_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>BLOCK PRINT DUPATTA</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
       
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_222907_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>KALAMKARI KNEE LENGTH DRESS</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br></br></br>
</div>
        
        <div class="page-header">
        <h1><c href="index.php">Clothing</c></h1>
        <p class="lead">MALE</p>
      </div>
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215308_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>COTTON SHORT KURTA</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215427_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>KALAMKARI BUSH SHIRT</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
        
      <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215447_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>CAMBRIC SLIM FIT SHIRT</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215323_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>LONG KURTA</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215342_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>CAMBRIC RED SHIRT</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_224054_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>CAMBRIC YELLOW SHIRT</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215357_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>PATTERN BUSH SHIRT BROWN</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
        <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215412_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>PATTERN BUSH SHIRT WHITE</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>
        
   <div class="col-md-4"> </br> 
<img src="img/IMG_07022020_215513_(500_x_500_pixel).jpg" width="300" alt="..." class="img-rounded">
<h4>BLOCK PRINTED SHIRT</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a></br></br></br>
</div>     
       
     
        
    </div> <!-- /container -->

<footer class="footer">
            Copyright&copy; TribalMarket. All Rights Reserved | Contact Us: +91 99900 00000
        </footer>
  </body>
</html>
