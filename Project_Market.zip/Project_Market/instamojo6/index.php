
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>TribalMarket</title>
    <link rel="shortcut icon" href="./img/srtcticon.png" type="image/png" >

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <link  href="style1.css" rel="stylesheet" type="text/css"/>
  </head>

  <body>
      <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
      <div class="header">
        <div class="inner-header">
            <div class="logo"><b><span class="glyphicon glyphicon-fire" aria-hidden="true"></span>TribalMarket</b></div>
             
      
               <div class="header-link"><a href="http://localhost/Emarket/login.php">Logout</a> </div>
               
                <div class="header-link"><a href="http://localhost/Emarketproductspage/index.php" >Dashboard</a> </div>
        </div>
    </div>
      
    
<div class="container">

      <div class="page-header">
        <h1><c href="index.php">Paintings</c></h1>
        
      </div>
      

    
  
<div class="col-md-4"> </br>
<img src="img/81q31AAlc6L._SY879_.jpg" width="300" alt="..." class="img-rounded">
<h4> MUD PAINTING</h4>
<h5> Price:11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>

<div class="col-md-4"> </br>
<img src="img/1483596838571_Tribal_Art-4__21397.1483678794.jpg" width="300" alt="..." class="img-rounded">
<h4> TRADITIONAL COUPLE  </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>


<div class="col-md-4"> </br>
<img src="img/1490979910573_gp28__79147.1491541301.jpg" width="300" alt="..." class="img-rounded">
<h4>MODERN ART  </h4>
<h5> Price:12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
      
    <div class="col-md-4"> </br> 
<img src="img/B3MKGEcjoQUTmD8DDEJJdA.jpg" width="300" alt="..." class="img-rounded">
<h4>HUNT ART  </h4>
<h5> Price: 13</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
       
        
       
       
        <div class="col-md-4"> </br> 
<img src="img/download (5).jpg" width="300" alt="..." class="img-rounded">
<h4>VILLAGE MUD ART  </h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
 <div class="col-md-4"> </br> 
<img src="img/images (1).jpg" width="300" alt="..." class="img-rounded">
<h4>CAVE PAINTING </h4>
<h5> Price: 15</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
    <div class="col-md-4"> </br> 
<img src="img/images (2).jpg" width="300" alt="..." class="img-rounded">
<h4>HERITAGE ART</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
        
 
        
        <div class="col-md-4"> </br> 
<img src="img/images (3).jpg" width="300" alt="..." class="img-rounded">
<h4>SUN ART</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
        
       
        
        

        
        <div class="col-md-4"> </br> 
<img src="img/images (4).jpg" width="300" alt="..." class="img-rounded">
<h4>FOLK ART</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    
        <div class="col-md-4"> </br> 
<img src="img/images (5).jpg" width="300" alt="..." class="img-rounded">
<h4>FESTIVE ART</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
        
    <div class="col-md-4"> </br> 
<img src="img/images (6).jpg" width="300" alt="..." class="img-rounded">
<h4>SCENERY</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    <div class="col-md-4"> </br> 
<img src="img/images (7).jpg" width="300" alt="..." class="img-rounded">
<h4>EMBROIDERY ART</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    <div class="col-md-4"> </br> 
<img src="img/images (8).jpg" width="300" alt="..." class="img-rounded">
<h4>DEER ART</h4>
<h5> Price: 11</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
    <div class="col-md-4"> </br> 
<img src="img/images (9).jpg" width="300" alt="..." class="img-rounded">
<h4>PEACOCK ART</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>

  <div class="col-md-4"> </br> 
<img src="img/images.jpg" width="300" alt="..." class="img-rounded">
<h4>BLACK AND WHITE ART</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
      
   <div class="col-md-4"> </br> 
<img src="img/Indian_Mughal_Art_-_Maharaj_Man_Singh_On_Horseback_-_Miniature_Painting_659e0e94-abf3-4430-b96d-90ae7c6624dc.jpg" width="300" alt="..." class="img-rounded">
<h4>ROYAL ART</h4>
<h5> Price: 12</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
     <div class="col-md-4"> </br> 
<img src="img/PP_-_02_6beedad2-f958-44b3-9ec2-86f6972404eb_1200x1200.jpg" width="300" alt="..." class="img-rounded">
<h4>CULTURAL ART</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
     <div class="col-md-4"> </br> 
<img src="img/Tribal Painting 2.jpg" width="300" alt="..." class="img-rounded">
<h4>ELEPHANT ART</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
     <div class="col-md-4"> </br> 
<img src="img/Tribes-India-Tribal-Painting-Gond-SDL601615605-1-b5938.jpg" width="300" alt="..." class="img-rounded">
<h4>TREE ART</h4>
<h5> Price: 14</h5>

<a href="INSTAMOJO_PAYMENT_LINK" target="_blank" class="btn btn-success"> Buy Now </a>
</div>
    
   
     
    
</div> <!-- /container --></br></br>
    
 <footer class="footer">
            Copyright&copy; TribalMarket. All Rights Reserved | Contact Us: +91 99900 00000
        </footer>  

  </body>
</html>
